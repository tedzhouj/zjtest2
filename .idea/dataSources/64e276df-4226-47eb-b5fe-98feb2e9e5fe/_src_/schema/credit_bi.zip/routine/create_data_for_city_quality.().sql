CREATE PROCEDURE `create_data_for_city_quality`()
  BEGIN
declare dd date;
declare i int;
declare j int;
set j = 1;
truncate table `credit_bi`.`odps_stats_city_quality`;

set i = Rand()*500000;

INSERT INTO `credit_bi`.`odps_stats_city_quality` 
(`ip_city`, `amount_one`, `amount_two`, `amount_three`, `amount_four`, `amount_five`, `amount_six`, `amount_seven`, `amount_eight`, `amount_nine`,
 `amount_ten`, `amount_eleven`, `amount_twelve`)
 VALUES ('杭州', i*0.89, i*0.75, i*0.65, i*0.55, i*0.45, i*0.35, i*0.25, i*0.16, i*0.13, i*0.121, i*0.111, i*0.101);

set i = Rand()*500000;

INSERT INTO `credit_bi`.`odps_stats_city_quality` 
(`ip_city`, `amount_one`, `amount_two`, `amount_three`, `amount_four`, `amount_five`, `amount_six`, `amount_seven`, `amount_eight`, `amount_nine`,
 `amount_ten`, `amount_eleven`, `amount_twelve`)
 VALUES ('上海', i*0.89, i*0.75, i*0.65, i*0.55, i*0.45, i*0.35, i*0.25, i*0.16, i*0.13, i*0.121, i*0.111, i*0.101);

set i = Rand()*500000;

INSERT INTO `credit_bi`.`odps_stats_city_quality` 
(`ip_city`, `amount_one`, `amount_two`, `amount_three`, `amount_four`, `amount_five`, `amount_six`, `amount_seven`, `amount_eight`, `amount_nine`,
 `amount_ten`, `amount_eleven`, `amount_twelve`)
 VALUES ('北京', i*0.89, i*0.75, i*0.65, i*0.55, i*0.45, i*0.35, i*0.25, i*0.16, i*0.13, i*0.121, i*0.111, i*0.101);

set i = Rand()*300000;

INSERT INTO `credit_bi`.`odps_stats_city_quality` 
(`ip_city`, `amount_one`, `amount_two`, `amount_three`, `amount_four`, `amount_five`, `amount_six`, `amount_seven`, `amount_eight`, `amount_nine`,
 `amount_ten`, `amount_eleven`, `amount_twelve`)
 VALUES ('西安', i*0.89, i*0.75, i*0.65, i*0.55, i*0.45, i*0.35, i*0.25, i*0.16, i*0.13, i*0.121, i*0.111, i*0.101);

set i = Rand()*400000;

INSERT INTO `credit_bi`.`odps_stats_city_quality` 
(`ip_city`, `amount_one`, `amount_two`, `amount_three`, `amount_four`, `amount_five`, `amount_six`, `amount_seven`, `amount_eight`, `amount_nine`,
 `amount_ten`, `amount_eleven`, `amount_twelve`)
 VALUES ('太原', i*0.89, i*0.75, i*0.65, i*0.55, i*0.45, i*0.35, i*0.25, i*0.16, i*0.13, i*0.121, i*0.111, i*0.101);

set i = Rand()*300000;

INSERT INTO `credit_bi`.`odps_stats_city_quality` 
(`ip_city`, `amount_one`, `amount_two`, `amount_three`, `amount_four`, `amount_five`, `amount_six`, `amount_seven`, `amount_eight`, `amount_nine`,
 `amount_ten`, `amount_eleven`, `amount_twelve`)
 VALUES ('南昌', i*0.89, i*0.75, i*0.65, i*0.55, i*0.45, i*0.35, i*0.25, i*0.16, i*0.13, i*0.121, i*0.111, i*0.101);


END