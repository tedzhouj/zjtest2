CREATE PROCEDURE `create_data_for_overdue_transfer`()
  BEGIN
declare dd date;
declare i int;
declare j int;
set j = 1;
set dd = date_add('2016-07-01 00:00:00',interval 0 day);
truncate table `credit_bi`.odps_stats_overdue_transfer;

 while j <= 8 do
   set i = Rand()*50000*j;
	INSERT INTO `credit_bi`.`odps_stats_overdue_transfer` 
(`repay_date`, `m0_amount`, `m1_amount`, `m2_amount`, `m3_amount`, `m4_amount`, `m5_amount`, `m6_amount`, `m7_amount`) 
VALUES ( date_format(dd ,'%Y-%m'),  i*0.87 , i*0.69 , i*0.52 , i*0.42, i*0.38, i*0.28, i*0.18, i*0.08);
	set dd = date_add(dd,interval 1 month);
	set j = j+1;
	end while;
END