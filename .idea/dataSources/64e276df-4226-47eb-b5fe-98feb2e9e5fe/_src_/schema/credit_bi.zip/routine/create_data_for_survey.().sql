CREATE PROCEDURE `create_data_for_survey`()
  BEGIN
declare dd date;
declare i int;
declare j int;
set j = 1;
set dd = date_add('2017-01-01 00:00:00',interval 1 day);
truncate table `credit_bi`.`odps_stats_operation_survey`;

 while j <= 100 do
   set i = Rand()*50000;
INSERT INTO `credit_bi`.`odps_stats_operation_survey`
(
`created_date`,
`register_pcount`,
`apply_pcount`,
`tiedcard_pcount`,
`withdraw_count`,
`withdraw_pcount`,
`withdraw_amount`)
VALUES
( 
dd,
i,
floor(i*0.6),
floor(i*0.3),
floor(i*0.28),
floor(i*0.05),
RAND()*5000000);

	set dd = date_add(dd,interval 1 day);
	set j = j+1;
	end while;
END