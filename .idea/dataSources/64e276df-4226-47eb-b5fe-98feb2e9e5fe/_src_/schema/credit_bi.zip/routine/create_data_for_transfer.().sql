CREATE PROCEDURE `create_data_for_transfer`()
  BEGIN
declare dd date;
declare i int;
declare j int;
set j = 1;
set dd = date_add('2017-01-01 00:00:00',interval 1 day);
truncate table `credit_bi`.`odps_stats_all_transfer`;

 while j <= 100 do
   set i = Rand()*50000;
INSERT INTO `credit_bi`.`odps_stats_all_transfer`
(`created_date`,
`reg_channel`,
`sub_channel`,
`register_pcount`,
`authid_pcount`,
`apply_pcount`,
`authcarrier_pcount`,
`loan_pcount`,
`loan_passpcount`,
`loan_reachpcount`,
`applywithdraw_pcount`,
`tiedcard_pcount`,
`withdraw_count`,
`withdraw_pcount`,
`withdraw_amount`)
VALUES
( dd,
'APP',
'',
i,
floor(i*0.9),
floor(i*0.8),
floor(i*0.7),
floor(i*0.6),
floor(i*0.5),
floor(i*0.4),
floor(i*0.3),
floor(i*0.2),
floor(i*0.1),
floor(i*0.05),
RAND()*1000000);

	INSERT INTO `credit_bi`.`odps_stats_all_transfer`
(`created_date`,
`reg_channel`,
`sub_channel`,
`register_pcount`,
`authid_pcount`,
`apply_pcount`,
`authcarrier_pcount`,
`loan_pcount`,
`loan_passpcount`,
`loan_reachpcount`,
`applywithdraw_pcount`,
`tiedcard_pcount`,
`withdraw_count`,
`withdraw_pcount`,
`withdraw_amount`)
VALUES
( dd,
'H5',
'001',
i,
floor(i*0.9),
floor(i*0.8),
floor(i*0.7),
floor(i*0.6),
floor(i*0.5),
floor(i*0.4),
floor(i*0.3),
floor(i*0.2),
floor(i*0.1),
floor(i*0.05),
RAND()*1000000);

INSERT INTO `credit_bi`.`odps_stats_all_transfer`
(`created_date`,
`reg_channel`,
`sub_channel`,
`register_pcount`,
`authid_pcount`,
`apply_pcount`,
`authcarrier_pcount`,
`loan_pcount`,
`loan_passpcount`,
`loan_reachpcount`,
`applywithdraw_pcount`,
`tiedcard_pcount`,
`withdraw_count`,
`withdraw_pcount`,
`withdraw_amount`)
VALUES
( dd,
'H5',
'002',
i,
floor(i*0.9),
floor(i*0.8),
floor(i*0.7),
floor(i*0.6),
floor(i*0.5),
floor(i*0.4),
floor(i*0.3),
floor(i*0.2),
floor(i*0.1),
floor(i*0.05),
RAND()*1000000);

INSERT INTO `credit_bi`.`odps_stats_all_transfer`
(`created_date`,
`reg_channel`,
`sub_channel`,
`register_pcount`,
`authid_pcount`,
`apply_pcount`,
`authcarrier_pcount`,
`loan_pcount`,
`loan_passpcount`,
`loan_reachpcount`,
`applywithdraw_pcount`,
`tiedcard_pcount`,
`withdraw_count`,
`withdraw_pcount`,
`withdraw_amount`)
VALUES
( dd,
'H5',
'003',
i,
floor(i*0.9),
floor(i*0.8),
floor(i*0.7),
floor(i*0.6),
floor(i*0.5),
floor(i*0.4),
floor(i*0.3),
floor(i*0.2),
floor(i*0.1),
floor(i*0.05),
RAND()*1000000);

	set dd = date_add(dd,interval 1 day);
	set j = j+1;
	end while;
END