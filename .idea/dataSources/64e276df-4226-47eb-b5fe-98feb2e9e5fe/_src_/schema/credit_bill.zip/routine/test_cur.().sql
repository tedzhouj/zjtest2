CREATE PROCEDURE `test_cur`()
  BEGIN

       DECLARE v_stages_id VARCHAR(32);
      DECLARE Done INT DEFAULT FALSE;
      DECLARE rs CURSOR FOR select stages_id from credit_bill.t_credit_interest where interest_time>'2017-03-31' and stages_id in(
select id from credit_bill.t_credit_stages where status='OPEN' and overdue_flag='YES' and repay_date>'2017-03-31'
) and status='OPEN';
     DECLARE CONTINUE HANDLER FOR NOT FOUND SET Done = TRUE;
      OPEN rs;  
     
      FETCH NEXT FROM rs INTO v_stages_id;     

      REPEAT
            INSERT into aaa select v_stages_id;
           
      FETCH NEXT FROM rs INTO v_stages_id;    
 
      UNTIL Done END REPEAT;
   close rs;
     
      /* 关闭游标 */
      CLOSE rs;


END